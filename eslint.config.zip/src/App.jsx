import { useState } from 'react'
import './App.css'
import ps from './assets/ps.png'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
    <header>
      <h1>Hi,I'm Abhishek Pandey</h1>
      <p>Web Developer|Designer|Programmer</p>
    </header>
    <img src={ps}/>
    <nav>
      <ul>
        <li><a href="#Home" className='Home'>Home</a></li>
        <li><a href="#About" className='About'>About</a></li>
        <li><a href="#Skills"className='Skills'>Skills</a></li>
        <li><a href="#qualification"className='Qualification'>Qualification</a></li>
        <li><a href="#Hobbies"className='Hobbies'>Hobbies</a></li>
      </ul>
    </nav>
    <div className='section'>
    <hr />
      <h2 id='self About'>Self About-</h2>
      <hr />
      <br />
      <br />
      <p>My Self, Abhishek Pandey From Uttar pradesh (India) <br />I Come From a Farmer family. <br />My Village is in Ambedkar Nagar District of Uttar Pradesh State.</p>
      <h3 id="skills">Skills-</h3>
      <p1>Html,Css,JavaScript,React,Node.js,Api,<br /> Bootstap,Python with Django.</p1>
      <hr />
      <h4 id="qualification">Qualification-</h4>
      <hr />
      <p>My Qualification is (B.A) Bachelor of Arts From <br /> Dr. Ram Manohar Lohia Avadh University <br /> Ayodhya,Uttar Pradesh.</p>
      <h5 id='hobbies'>My Hobbies-</h5>
      <h6>I like Playing Cricket,Listening to Music, <br />Reading Old Horror and Adventure Stories, <br />Travelling,Walking And Etc..</h6>
    </div>
    <div className='footer'>
      <p>&copy;Samyak Infotech.</p>
      </div>
    
    </>
  )
}

export default App
